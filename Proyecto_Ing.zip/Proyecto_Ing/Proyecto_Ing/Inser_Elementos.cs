﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace Proyecto_Ing
{
    class Inser_Elementos
    {
        String nomBD = "Almacenes";
        Conexion objcon = new Conexion();
        SqlConnection Conector;
        string Mensaje="";
        public Inser_Elementos()
        {

        }

        public bool Insert_Adm(Int32 Ced, string Us, string Nom, string Ape, string Tel, string Cla)
        {
            
            Conector = objcon.conectar(nomBD);
            string conSQL = "Agregar_Adm";
            SqlCommand comando = new SqlCommand(conSQL, Conector);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.Add("@Ced", SqlDbType.BigInt).SqlValue = Ced;
            comando.Parameters.Add("@Usuario", SqlDbType.NVarChar).SqlValue = Us;
            comando.Parameters.Add("@Nombre", SqlDbType.NVarChar).SqlValue = Nom;
            comando.Parameters.Add("@Apellido", SqlDbType.NVarChar).SqlValue = Ape;
            comando.Parameters.Add("@Tel", SqlDbType.NVarChar).SqlValue = Tel;
            comando.Parameters.Add("@Clave", SqlDbType.NVarChar).SqlValue = Cla;
            SqlDataReader tabla = comando.ExecuteReader();
            if (tabla.Read())
            {
                objcon.cerrar(Conector);
                return true;
            }
            else
            {
                objcon.cerrar(Conector);
                return false;
            }



        }

        public string getMensaje()
        {
            return Mensaje;
        }

        public bool Insert_Emp(Int32 Ced, string Us, string Nom, string Ape, string Tel, string Cla)
        {

            Conector = objcon.conectar(nomBD);
            string conSQL = "Agregar_Emp";
            SqlCommand comando = new SqlCommand(conSQL, Conector);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.Add("@Ced", SqlDbType.BigInt).SqlValue = Ced;
            comando.Parameters.Add("@Usuario", SqlDbType.NVarChar).SqlValue = Us;
            comando.Parameters.Add("@Nombre", SqlDbType.NVarChar).SqlValue = Nom;
            comando.Parameters.Add("@Apellido", SqlDbType.NVarChar).SqlValue = Ape;
            comando.Parameters.Add("@Tel", SqlDbType.NVarChar).SqlValue = Tel;
            comando.Parameters.Add("@Clave", SqlDbType.NVarChar).SqlValue = Cla;
            SqlDataReader tabla = comando.ExecuteReader();

            if (tabla.Read())
            {
                objcon.cerrar(Conector);
                return true;                
            }
            else
            {
                objcon.cerrar(Conector);
                return false;
            }
        }

        public void Acceder(string us, string ced, string fec, string hor)
        {
            Conector = objcon.conectar(nomBD);
            string conSQL = "Acceso";
            SqlCommand comando = new SqlCommand(conSQL, Conector);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.Add("@Ced", SqlDbType.BigInt).SqlValue = ced;
            comando.Parameters.Add("@Usuario", SqlDbType.NVarChar).SqlValue = us;
            comando.Parameters.Add("@Hora", SqlDbType.NVarChar).SqlValue = hor;
            comando.Parameters.Add("@fecha", SqlDbType.NVarChar).SqlValue = fec;
            SqlDataReader tabla = comando.ExecuteReader();
            objcon.cerrar(Conector);
        }

      

        public string Cosulta_Ced(string us)
        {
            string Ced="";
            try { 

            Conector = objcon.conectar(nomBD);
            string conSQL = "Consultausu";
            SqlCommand comando = new SqlCommand(conSQL, Conector);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.Add("@usu", SqlDbType.NVarChar).SqlValue = us;
            SqlDataReader tabla = comando.ExecuteReader();
                if (tabla.Read())
                {
                  Ced  = tabla[0].ToString();
                }
                objcon.cerrar(Conector);
                return Ced;

                }
            catch(Exception eq)
            {
                Mensaje = eq.Message;
                return "";
            }

        }



    }
}
