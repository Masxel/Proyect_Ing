﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Proyecto_Ing
{
    public partial class Ingreso : Form
    {
        public string strFecha;
        public int inthr = 0, intmin = 0, intseg = 0;
        private string aux="";
        public Ingreso()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void timer1_Tick(object sender, EventArgs e)
        {
            intseg += 1;

            string segundo = intseg.ToString();
            string minuto = intmin.ToString();
            string hora = inthr.ToString();

            if (intseg > 59)
            {
                intmin += 1;
                intseg = 0;
            }

            if (intmin > 59)
            {
                inthr += 1;
                intmin = 0;
            }

            if (intseg < 10) { segundo = "0" + intseg.ToString(); }
            if (intmin < 10) { minuto = "0" + intmin.ToString(); }
            if (inthr < 10) { hora = "0" + inthr.ToString(); }
            lblHora.Text = hora + ":" + minuto + ":" + segundo;
        }

        private void Ingreso_Load(object sender, EventArgs e)
        {
            Tiempo();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {

            String nomBD = "Almacenes";
            Conexion objcon = new Conexion();
            SqlConnection Conector;
            SqlDataReader tabla;
            string strUsuario = txtUsuario.Text;
            string strClave = txtClave.Text;

            if (strClave == "" || strUsuario == "")
            {
                MessageBox.Show("Se deben ingresar datos");
            }
            else
            {
                try
                {
                Conector = objcon.conectar(nomBD);
                string conSQL = "select * from Loguin where Usuario = '" + strUsuario + "'";
                tabla = objcon.consulta(conSQL, Conector);

                
                    if (tabla.Read())
                    {
                        if (strClave == tabla[2].ToString())
                        {
                            MessageBox.Show("El valor del rol es :" + tabla[3].ToString());
                            if (tabla[3].ToString() == "Administrador")
                            {
                                Panel_Adm objA = new Panel_Adm();
                                objA.Show();
                                Acceso();

                            }
                            else
                            {
                                Panel_Emp objE = new Panel_Emp();
                                objE.Show();
                                Acceso();
                            }
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Clave Incorrecta");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Usuario Inexistente");
                    }
                    tabla.Close();
                    objcon.cerrar(Conector);
                }
                catch (SqlException ve)
                {
                    MessageBox.Show(ve.Message);
                }
            }
        }

        private void Acceso()
        {
            Inser_Elementos objI = new Inser_Elementos();
            aux=objI.Cosulta_Ced(txtUsuario.Text);
             if (aux!=""){
                objI.Acceder(txtUsuario.Text, aux, lblFecha.Text, lblHora.Text);
            }
            else
            {
                MessageBox.Show("Hubo un error en el registro de acceso");
            }
        }

       public void Tiempo()
        {
            inthr = DateTime.Now.Hour;
            intmin = DateTime.Now.Minute;
            intseg = DateTime.Now.Second;
            timer1.Start();
            strFecha = DateTime.Today.Day + "/" + DateTime.Today.Month + "/" + DateTime.Today.Year;
            lblFecha.Text = strFecha;
        }

    }
}