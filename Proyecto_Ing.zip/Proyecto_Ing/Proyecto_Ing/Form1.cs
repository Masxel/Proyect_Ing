﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Ing
{
    public partial class Form1 : Form
    {
        string strFecha;
        int inthr = 0, intmin = 0, intseg = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Tiempo();
            Transp();
        }

        private void Transp()
        {
            lblMenu.BackColor = Color.Transparent;
            btnAdministrador.BackColor = Color.Transparent;;
            btnEmpleado.BackColor = Color.Transparent;
            lblHora.BackColor = Color.Transparent;
            lblFecha.BackColor = Color.Transparent;
          
        }

        private void btnAdministrador_Click(object sender, EventArgs e)
        {
            this.Hide();
            Ingreso objI = new Ingreso();
            objI.Show();
            objI = null;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblHora_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            intseg += 1;

            string segundo = intseg.ToString();
            string minuto = intmin.ToString();
            string hora = inthr.ToString();

            if (intseg > 59)
            {
                intmin += 1;
                intseg = 0;
            }

            if (intmin > 59)
            {
                inthr += 1;
                intmin = 0;
            }

            if (intseg < 10) { segundo = "0" + intseg.ToString(); }
            if (intmin < 10) { minuto = "0" + intmin.ToString(); }
            if (inthr < 10) { hora = "0" + inthr.ToString(); }
            lblHora.Text = hora+ ":"+ minuto + ":" + segundo;
        }

        private void Tiempo()
        {
            inthr = DateTime.Now.Hour;
            intmin = DateTime.Now.Minute;
            intseg = DateTime.Now.Second;
            timer1.Start();
            strFecha = DateTime.Today.Day + "/" + DateTime.Today.Month + "/" + DateTime.Today.Year;
            lblFecha.Text = strFecha;
        }
    }
}
