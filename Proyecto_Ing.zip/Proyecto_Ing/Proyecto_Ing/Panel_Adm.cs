﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Ing
{
    public partial class Panel_Adm : Form
    {
        int inthr = 0, intmin = 0, intseg = 0;
        public Panel_Adm()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Ingreso objR = new Ingreso();
            this.Close();
            objR.Show();
        }

        private void lklblImagen_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                this.openFileDialog1.ShowDialog();
                if(this.openFileDialog1.FileName.Equals("")==false)
                {
                    pcbRegistra.Load(this.openFileDialog1.FileName);
                }
            } catch(Exception ex)
            {
                MessageBox.Show("No se pudo cargar la imagen "+ex.ToString());
            }
        }

        private void btnRegistrarE_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 Ced = Int32.Parse(txtCedulaE.Text);
                string Us = txtUsuarioE.Text;
                string Nom = txtNombreE.Text;
                string Ape = txtApellidoE.Text;
                string Tel = txtTelefonoE.Text;
                string Cla = txtClaveE2.Text;
                if (txtClaveE.Text == Cla)
                {
                    Inser_Elementos obI = new Inser_Elementos();
                    if (!obI.Insert_Emp(Ced, Us, Nom, Ape, Tel, Cla))
                    {
                        txtMensaje.Text = "El empleado ha sido agregado exitosamente";
                        txtNombreE.Clear();
                        txtApellidoE.Clear();
                        txtUsuarioE.Clear();
                        txtClaveE.Clear();
                        txtClaveE2.Clear();
                        txtTelefonoE.Clear();
                        txtCedulaE.Clear();
                    }
                    else
                    {
                        txtMensaje.Text = "El empleado no pudo ser agregado";
                    }
                }
                else
                {
                    txtMensaje.Text = "Las contraseñas no coinciden";
                }

            }
            catch (Exception ex)
            {
                txtMensaje.Text = ex.ToString();
            }
        }

        private void Panel_Adm_Load(object sender, EventArgs e)
        {
            Ingreso objI = new Ingreso();
            objI.Tiempo();
            lblFecha.Text = objI.lblFecha.Text;
            timer1.Start();
            intseg = objI.intseg;
            intmin = objI.intmin;
            inthr = objI.inthr;
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            intseg += 1;

            string segundo = intseg.ToString();
            string minuto = intmin.ToString();
            string hora = inthr.ToString();

            if (intseg > 59)
            {
                intmin += 1;
                intseg = 0;
            }

            if (intmin > 59)
            {
                inthr += 1;
                intmin = 0;
            }

            if (intseg < 10) { segundo = "0" + intseg.ToString(); }
            if (intmin < 10) { minuto = "0" + intmin.ToString(); }
            if (inthr < 10) { hora = "0" + inthr.ToString(); }
            lblHora.Text = hora + ":" + minuto + ":" + segundo;
        }
    }











}
