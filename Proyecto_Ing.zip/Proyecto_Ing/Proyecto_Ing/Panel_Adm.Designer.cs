﻿namespace Proyecto_Ing
{
    partial class Panel_Adm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtTelefonoE = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtUsuarioE = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.btnRegistrarE = new System.Windows.Forms.Button();
            this.txtNombreE = new System.Windows.Forms.TextBox();
            this.txtClaveE2 = new System.Windows.Forms.TextBox();
            this.txtClaveE = new System.Windows.Forms.TextBox();
            this.txtCedulaE = new System.Windows.Forms.TextBox();
            this.txtApellidoE = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lklblImagen = new System.Windows.Forms.LinkLabel();
            this.pcbRegistra = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.rbEuropa = new System.Windows.Forms.RadioButton();
            this.rbAsia = new System.Windows.Forms.RadioButton();
            this.rbAmerica = new System.Windows.Forms.RadioButton();
            this.txtCostoA = new System.Windows.Forms.TextBox();
            this.txtNombreA = new System.Windows.Forms.TextBox();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.txtCodigoI = new System.Windows.Forms.TextBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnRegistroM = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pcbBuscar = new System.Windows.Forms.PictureBox();
            this.lblOrigen = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lblCostosV = new System.Windows.Forms.Label();
            this.lblCostos = new System.Windows.Forms.Label();
            this.lblTipo = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.txtCogioBA = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtCodigoB = new System.Windows.Forms.TextBox();
            this.lblUnidades = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnBusqueda = new System.Windows.Forms.Button();
            this.btnBusca = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.txtBuscaE = new System.Windows.Forms.TextBox();
            this.lblAumento = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.lblVentasE = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lblApellidoE = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblNombreE = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnBuscaE = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnBuscaA = new System.Windows.Forms.Button();
            this.txtBuscarA = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.txtTelefonoA = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtUsuarioA = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.btnRegistrarA = new System.Windows.Forms.Button();
            this.txtNombreAd = new System.Windows.Forms.TextBox();
            this.txtClaveA2 = new System.Windows.Forms.TextBox();
            this.txtClaveA = new System.Windows.Forms.TextBox();
            this.txtCedulaA = new System.Windows.Forms.TextBox();
            this.txtApellidoA = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnProbar = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtMensaje = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbRegistra)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbBuscar)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(12, 85);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(608, 579);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage1.Controls.Add(this.txtTelefonoE);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.txtUsuarioE);
            this.tabPage1.Controls.Add(this.label37);
            this.tabPage1.Controls.Add(this.btnRegistrarE);
            this.tabPage1.Controls.Add(this.txtNombreE);
            this.tabPage1.Controls.Add(this.txtClaveE2);
            this.tabPage1.Controls.Add(this.txtClaveE);
            this.tabPage1.Controls.Add(this.txtCedulaE);
            this.tabPage1.Controls.Add(this.txtApellidoE);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(600, 553);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "REGISTRO DE EMPLEADOS";
            // 
            // txtTelefonoE
            // 
            this.txtTelefonoE.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefonoE.Location = new System.Drawing.Point(226, 271);
            this.txtTelefonoE.Name = "txtTelefonoE";
            this.txtTelefonoE.Size = new System.Drawing.Size(196, 22);
            this.txtTelefonoE.TabIndex = 5;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(39, 271);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(63, 15);
            this.label38.TabIndex = 12;
            this.label38.Text = "Telefono";
            // 
            // txtUsuarioE
            // 
            this.txtUsuarioE.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioE.Location = new System.Drawing.Point(226, 48);
            this.txtUsuarioE.Name = "txtUsuarioE";
            this.txtUsuarioE.Size = new System.Drawing.Size(196, 22);
            this.txtUsuarioE.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(39, 48);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 15);
            this.label37.TabIndex = 10;
            this.label37.Text = "Usuario";
            // 
            // btnRegistrarE
            // 
            this.btnRegistrarE.Image = global::Proyecto_Ing.Properties.Resources.group_edit;
            this.btnRegistrarE.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegistrarE.Location = new System.Drawing.Point(226, 449);
            this.btnRegistrarE.Name = "btnRegistrarE";
            this.btnRegistrarE.Size = new System.Drawing.Size(120, 49);
            this.btnRegistrarE.TabIndex = 8;
            this.btnRegistrarE.Text = "REGISTRAR";
            this.btnRegistrarE.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRegistrarE.UseVisualStyleBackColor = true;
            this.btnRegistrarE.Click += new System.EventHandler(this.btnRegistrarE_Click);
            // 
            // txtNombreE
            // 
            this.txtNombreE.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreE.Location = new System.Drawing.Point(226, 103);
            this.txtNombreE.Name = "txtNombreE";
            this.txtNombreE.Size = new System.Drawing.Size(196, 22);
            this.txtNombreE.TabIndex = 2;
            // 
            // txtClaveE2
            // 
            this.txtClaveE2.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClaveE2.Location = new System.Drawing.Point(226, 388);
            this.txtClaveE2.Name = "txtClaveE2";
            this.txtClaveE2.PasswordChar = '*';
            this.txtClaveE2.Size = new System.Drawing.Size(196, 22);
            this.txtClaveE2.TabIndex = 7;
            // 
            // txtClaveE
            // 
            this.txtClaveE.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClaveE.Location = new System.Drawing.Point(226, 326);
            this.txtClaveE.Name = "txtClaveE";
            this.txtClaveE.PasswordChar = '*';
            this.txtClaveE.Size = new System.Drawing.Size(196, 22);
            this.txtClaveE.TabIndex = 6;
            // 
            // txtCedulaE
            // 
            this.txtCedulaE.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCedulaE.Location = new System.Drawing.Point(226, 214);
            this.txtCedulaE.Name = "txtCedulaE";
            this.txtCedulaE.Size = new System.Drawing.Size(196, 22);
            this.txtCedulaE.TabIndex = 4;
            // 
            // txtApellidoE
            // 
            this.txtApellidoE.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidoE.Location = new System.Drawing.Point(226, 161);
            this.txtApellidoE.Name = "txtApellidoE";
            this.txtApellidoE.Size = new System.Drawing.Size(196, 22);
            this.txtApellidoE.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(39, 387);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Confirmar Contraseña";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(39, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Contraseña";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(39, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Cedula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Apellido";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nombre";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage2.Controls.Add(this.lklblImagen);
            this.tabPage2.Controls.Add(this.pcbRegistra);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.rbEuropa);
            this.tabPage2.Controls.Add(this.rbAsia);
            this.tabPage2.Controls.Add(this.rbAmerica);
            this.tabPage2.Controls.Add(this.txtCostoA);
            this.tabPage2.Controls.Add(this.txtNombreA);
            this.tabPage2.Controls.Add(this.txtMarca);
            this.tabPage2.Controls.Add(this.txtCodigoI);
            this.tabPage2.Controls.Add(this.lblCosto);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.btnRegistroM);
            this.tabPage2.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(600, 553);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "IMPORTACIONES";
            // 
            // lklblImagen
            // 
            this.lklblImagen.AutoSize = true;
            this.lklblImagen.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lklblImagen.Location = new System.Drawing.Point(441, 293);
            this.lklblImagen.Name = "lklblImagen";
            this.lklblImagen.Size = new System.Drawing.Size(98, 15);
            this.lklblImagen.TabIndex = 16;
            this.lklblImagen.TabStop = true;
            this.lklblImagen.Text = "Cargar Imagen";
            this.lklblImagen.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lklblImagen_LinkClicked);
            // 
            // pcbRegistra
            // 
            this.pcbRegistra.Location = new System.Drawing.Point(383, 83);
            this.pcbRegistra.Name = "pcbRegistra";
            this.pcbRegistra.Size = new System.Drawing.Size(211, 185);
            this.pcbRegistra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbRegistra.TabIndex = 15;
            this.pcbRegistra.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(40, 21);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(220, 22);
            this.label22.TabIndex = 14;
            this.label22.Text = "REGISTRO DE ARTICULOS";
            // 
            // rbEuropa
            // 
            this.rbEuropa.AutoSize = true;
            this.rbEuropa.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbEuropa.Location = new System.Drawing.Point(196, 400);
            this.rbEuropa.Name = "rbEuropa";
            this.rbEuropa.Size = new System.Drawing.Size(67, 18);
            this.rbEuropa.TabIndex = 13;
            this.rbEuropa.Text = "Europa";
            this.rbEuropa.UseVisualStyleBackColor = true;
            // 
            // rbAsia
            // 
            this.rbAsia.AutoSize = true;
            this.rbAsia.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAsia.Location = new System.Drawing.Point(196, 363);
            this.rbAsia.Name = "rbAsia";
            this.rbAsia.Size = new System.Drawing.Size(53, 18);
            this.rbAsia.TabIndex = 12;
            this.rbAsia.Text = "Asia";
            this.rbAsia.UseVisualStyleBackColor = true;
            // 
            // rbAmerica
            // 
            this.rbAmerica.AutoSize = true;
            this.rbAmerica.Checked = true;
            this.rbAmerica.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAmerica.Location = new System.Drawing.Point(196, 326);
            this.rbAmerica.Name = "rbAmerica";
            this.rbAmerica.Size = new System.Drawing.Size(74, 18);
            this.rbAmerica.TabIndex = 11;
            this.rbAmerica.TabStop = true;
            this.rbAmerica.Text = "America";
            this.rbAmerica.UseVisualStyleBackColor = true;
            // 
            // txtCostoA
            // 
            this.txtCostoA.Location = new System.Drawing.Point(167, 267);
            this.txtCostoA.Name = "txtCostoA";
            this.txtCostoA.Size = new System.Drawing.Size(175, 20);
            this.txtCostoA.TabIndex = 10;
            // 
            // txtNombreA
            // 
            this.txtNombreA.Location = new System.Drawing.Point(167, 206);
            this.txtNombreA.Name = "txtNombreA";
            this.txtNombreA.Size = new System.Drawing.Size(175, 20);
            this.txtNombreA.TabIndex = 9;
            // 
            // txtMarca
            // 
            this.txtMarca.Location = new System.Drawing.Point(167, 139);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.Size = new System.Drawing.Size(175, 20);
            this.txtMarca.TabIndex = 8;
            // 
            // txtCodigoI
            // 
            this.txtCodigoI.Location = new System.Drawing.Point(167, 83);
            this.txtCodigoI.Name = "txtCodigoI";
            this.txtCodigoI.Size = new System.Drawing.Size(175, 20);
            this.txtCodigoI.TabIndex = 7;
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCosto.Location = new System.Drawing.Point(308, 458);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(14, 14);
            this.lblCosto.TabIndex = 6;
            this.lblCosto.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(39, 458);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(231, 14);
            this.label12.TabIndex = 5;
            this.label12.Text = "Costo Del Producto Para La Venta";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(41, 367);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(127, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Continente De Origen";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(55, 267);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 14);
            this.label10.TabIndex = 3;
            this.label10.Text = "Costo Articulo";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(48, 208);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 14);
            this.label9.TabIndex = 2;
            this.label9.Text = "Nombre Articulo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(111, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 14);
            this.label8.TabIndex = 1;
            this.label8.Text = "Marca";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(41, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 14);
            this.label7.TabIndex = 0;
            this.label7.Text = "Codigo Articulo";
            // 
            // btnRegistroM
            // 
            this.btnRegistroM.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnRegistroM.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistroM.Image = global::Proyecto_Ing.Properties.Resources.table_edit;
            this.btnRegistroM.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegistroM.Location = new System.Drawing.Point(404, 439);
            this.btnRegistroM.Name = "btnRegistroM";
            this.btnRegistroM.Size = new System.Drawing.Size(135, 50);
            this.btnRegistroM.TabIndex = 4;
            this.btnRegistroM.Text = "REGISTRAR";
            this.btnRegistroM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRegistroM.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage3.Controls.Add(this.pcbBuscar);
            this.tabPage3.Controls.Add(this.lblOrigen);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.lblCostosV);
            this.tabPage3.Controls.Add(this.lblCostos);
            this.tabPage3.Controls.Add(this.lblTipo);
            this.tabPage3.Controls.Add(this.lblMarca);
            this.tabPage3.Controls.Add(this.txtCogioBA);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.txtCodigoB);
            this.tabPage3.Controls.Add(this.lblUnidades);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.btnBusqueda);
            this.tabPage3.Controls.Add(this.btnBusca);
            this.tabPage3.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(600, 553);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "ALMACEN";
            // 
            // pcbBuscar
            // 
            this.pcbBuscar.Location = new System.Drawing.Point(358, 327);
            this.pcbBuscar.Name = "pcbBuscar";
            this.pcbBuscar.Size = new System.Drawing.Size(200, 202);
            this.pcbBuscar.TabIndex = 20;
            this.pcbBuscar.TabStop = false;
            // 
            // lblOrigen
            // 
            this.lblOrigen.AutoSize = true;
            this.lblOrigen.Location = new System.Drawing.Point(216, 520);
            this.lblOrigen.Name = "lblOrigen";
            this.lblOrigen.Size = new System.Drawing.Size(28, 14);
            this.lblOrigen.TabIndex = 19;
            this.lblOrigen.Text = "---";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(43, 520);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(49, 14);
            this.label26.TabIndex = 18;
            this.label26.Text = "ORIGEN";
            // 
            // lblCostosV
            // 
            this.lblCostosV.AutoSize = true;
            this.lblCostosV.Location = new System.Drawing.Point(216, 478);
            this.lblCostosV.Name = "lblCostosV";
            this.lblCostosV.Size = new System.Drawing.Size(28, 14);
            this.lblCostosV.TabIndex = 16;
            this.lblCostosV.Text = "---";
            // 
            // lblCostos
            // 
            this.lblCostos.AutoSize = true;
            this.lblCostos.Location = new System.Drawing.Point(216, 431);
            this.lblCostos.Name = "lblCostos";
            this.lblCostos.Size = new System.Drawing.Size(28, 14);
            this.lblCostos.TabIndex = 15;
            this.lblCostos.Text = "---";
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Location = new System.Drawing.Point(216, 381);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(28, 14);
            this.lblTipo.TabIndex = 14;
            this.lblTipo.Text = "---";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(216, 327);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(28, 14);
            this.lblMarca.TabIndex = 13;
            this.lblMarca.Text = "---";
            // 
            // txtCogioBA
            // 
            this.txtCogioBA.Location = new System.Drawing.Point(219, 274);
            this.txtCogioBA.Name = "txtCogioBA";
            this.txtCogioBA.Size = new System.Drawing.Size(171, 22);
            this.txtCogioBA.TabIndex = 12;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(42, 478);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(126, 14);
            this.label21.TabIndex = 11;
            this.label21.Text = "PRECIO AL PUBLICO";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(43, 431);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 14);
            this.label20.TabIndex = 10;
            this.label20.Text = "COSTO";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(43, 381);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 14);
            this.label19.TabIndex = 9;
            this.label19.Text = "TIPO";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(43, 327);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 14);
            this.label18.TabIndex = 8;
            this.label18.Text = "MARCA";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(43, 277);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(133, 14);
            this.label17.TabIndex = 7;
            this.label17.Text = "CODIGO DE PRODUCTO";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(42, 26);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(180, 22);
            this.label16.TabIndex = 6;
            this.label16.Text = "BUSQUEDA ARTICULO";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(42, 218);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(180, 22);
            this.label15.TabIndex = 5;
            this.label15.Text = "BUSQUEDA AVANZADA";
            // 
            // txtCodigoB
            // 
            this.txtCodigoB.Location = new System.Drawing.Point(219, 88);
            this.txtCodigoB.Name = "txtCodigoB";
            this.txtCodigoB.Size = new System.Drawing.Size(154, 22);
            this.txtCodigoB.TabIndex = 3;
            // 
            // lblUnidades
            // 
            this.lblUnidades.AutoSize = true;
            this.lblUnidades.Location = new System.Drawing.Point(216, 152);
            this.lblUnidades.Name = "lblUnidades";
            this.lblUnidades.Size = new System.Drawing.Size(14, 14);
            this.lblUnidades.TabIndex = 2;
            this.lblUnidades.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(42, 152);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(147, 14);
            this.label14.TabIndex = 1;
            this.label14.Text = "UNIDADES DISPONIBLES";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(42, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(161, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "NOMBRE DE LA MERCANCIA";
            // 
            // btnBusqueda
            // 
            this.btnBusqueda.Image = global::Proyecto_Ing.Properties.Resources.folder_explore;
            this.btnBusqueda.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBusqueda.Location = new System.Drawing.Point(443, 261);
            this.btnBusqueda.Name = "btnBusqueda";
            this.btnBusqueda.Size = new System.Drawing.Size(106, 46);
            this.btnBusqueda.TabIndex = 17;
            this.btnBusqueda.Text = "BUSQUEDA";
            this.btnBusqueda.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBusqueda.UseVisualStyleBackColor = true;
            // 
            // btnBusca
            // 
            this.btnBusca.Image = global::Proyecto_Ing.Properties.Resources.folder_find;
            this.btnBusca.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBusca.Location = new System.Drawing.Point(443, 78);
            this.btnBusca.Name = "btnBusca";
            this.btnBusca.Size = new System.Drawing.Size(98, 46);
            this.btnBusca.TabIndex = 4;
            this.btnBusca.Text = "BUSCAR";
            this.btnBusca.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBusca.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage4.Controls.Add(this.txtBuscaE);
            this.tabPage4.Controls.Add(this.lblAumento);
            this.tabPage4.Controls.Add(this.label33);
            this.tabPage4.Controls.Add(this.lblVentasE);
            this.tabPage4.Controls.Add(this.label31);
            this.tabPage4.Controls.Add(this.lblApellidoE);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.lblNombreE);
            this.tabPage4.Controls.Add(this.label27);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.btnBuscaE);
            this.tabPage4.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(600, 553);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "VENTAS";
            // 
            // txtBuscaE
            // 
            this.txtBuscaE.Location = new System.Drawing.Point(194, 83);
            this.txtBuscaE.Name = "txtBuscaE";
            this.txtBuscaE.Size = new System.Drawing.Size(155, 23);
            this.txtBuscaE.TabIndex = 12;
            // 
            // lblAumento
            // 
            this.lblAumento.AutoSize = true;
            this.lblAumento.Location = new System.Drawing.Point(192, 399);
            this.lblAumento.Name = "lblAumento";
            this.lblAumento.Size = new System.Drawing.Size(21, 15);
            this.lblAumento.TabIndex = 10;
            this.lblAumento.Text = "0%";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(29, 399);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(147, 15);
            this.label33.TabIndex = 9;
            this.label33.Text = "Aumento En El Sueldo";
            // 
            // lblVentasE
            // 
            this.lblVentasE.AutoSize = true;
            this.lblVentasE.Location = new System.Drawing.Point(192, 325);
            this.lblVentasE.Name = "lblVentasE";
            this.lblVentasE.Size = new System.Drawing.Size(14, 15);
            this.lblVentasE.TabIndex = 8;
            this.lblVentasE.Text = "0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(29, 325);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(119, 15);
            this.label31.TabIndex = 7;
            this.label31.Text = "Numero De Ventas";
            // 
            // lblApellidoE
            // 
            this.lblApellidoE.AutoSize = true;
            this.lblApellidoE.Location = new System.Drawing.Point(192, 246);
            this.lblApellidoE.Name = "lblApellidoE";
            this.lblApellidoE.Size = new System.Drawing.Size(28, 15);
            this.lblApellidoE.TabIndex = 6;
            this.lblApellidoE.Text = "---";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(22, 246);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(154, 15);
            this.label29.TabIndex = 5;
            this.label29.Text = "Apellido Del Empleado";
            // 
            // lblNombreE
            // 
            this.lblNombreE.AutoSize = true;
            this.lblNombreE.Location = new System.Drawing.Point(192, 172);
            this.lblNombreE.Name = "lblNombreE";
            this.lblNombreE.Size = new System.Drawing.Size(28, 15);
            this.lblNombreE.TabIndex = 4;
            this.lblNombreE.Text = "---";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(29, 172);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(140, 15);
            this.label27.TabIndex = 3;
            this.label27.Text = "Nombre Del Empleado";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(29, 91);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(112, 15);
            this.label24.TabIndex = 1;
            this.label24.Text = "CEDULA EMPLEADO";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(28, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(190, 22);
            this.label23.TabIndex = 0;
            this.label23.Text = "VENTA POR EMPLEADO";
            // 
            // btnBuscaE
            // 
            this.btnBuscaE.Image = global::Proyecto_Ing.Properties.Resources.folder_user;
            this.btnBuscaE.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscaE.Location = new System.Drawing.Point(32, 463);
            this.btnBuscaE.Name = "btnBuscaE";
            this.btnBuscaE.Size = new System.Drawing.Size(153, 41);
            this.btnBuscaE.TabIndex = 11;
            this.btnBuscaE.Text = "BUSCAR EMPLEADO";
            this.btnBuscaE.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscaE.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage5.Controls.Add(this.btnBuscaA);
            this.tabPage5.Controls.Add(this.txtBuscarA);
            this.tabPage5.Controls.Add(this.label36);
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this.label32);
            this.tabPage5.Controls.Add(this.label30);
            this.tabPage5.Controls.Add(this.label28);
            this.tabPage5.Controls.Add(this.label25);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(600, 553);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "ACCESO";
            // 
            // btnBuscaA
            // 
            this.btnBuscaA.Image = global::Proyecto_Ing.Properties.Resources.icons8_horas_extras_48;
            this.btnBuscaA.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscaA.Location = new System.Drawing.Point(34, 335);
            this.btnBuscaA.Name = "btnBuscaA";
            this.btnBuscaA.Size = new System.Drawing.Size(156, 44);
            this.btnBuscaA.TabIndex = 8;
            this.btnBuscaA.Text = "BUSCAR ACCESO";
            this.btnBuscaA.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscaA.UseVisualStyleBackColor = true;
            // 
            // txtBuscarA
            // 
            this.txtBuscarA.Location = new System.Drawing.Point(156, 70);
            this.txtBuscarA.Name = "txtBuscarA";
            this.txtBuscarA.Size = new System.Drawing.Size(148, 20);
            this.txtBuscarA.TabIndex = 7;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(153, 268);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(16, 13);
            this.label36.TabIndex = 6;
            this.label36.Text = "---";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(153, 198);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(16, 13);
            this.label35.TabIndex = 5;
            this.label35.Text = "---";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(153, 132);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(16, 13);
            this.label34.TabIndex = 4;
            this.label34.Text = "---";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(31, 268);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(42, 13);
            this.label32.TabIndex = 3;
            this.label32.Text = "FECHA";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(31, 198);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(38, 13);
            this.label30.TabIndex = 2;
            this.label30.Text = "HORA";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(31, 132);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(54, 13);
            this.label28.TabIndex = 1;
            this.label28.Text = "NOMBRE";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(31, 70);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(50, 13);
            this.label25.TabIndex = 0;
            this.label25.Text = "CEDULA";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage6.Controls.Add(this.txtTelefonoA);
            this.tabPage6.Controls.Add(this.label39);
            this.tabPage6.Controls.Add(this.txtUsuarioA);
            this.tabPage6.Controls.Add(this.label40);
            this.tabPage6.Controls.Add(this.btnRegistrarA);
            this.tabPage6.Controls.Add(this.txtNombreAd);
            this.tabPage6.Controls.Add(this.txtClaveA2);
            this.tabPage6.Controls.Add(this.txtClaveA);
            this.tabPage6.Controls.Add(this.txtCedulaA);
            this.tabPage6.Controls.Add(this.txtApellidoA);
            this.tabPage6.Controls.Add(this.label41);
            this.tabPage6.Controls.Add(this.label42);
            this.tabPage6.Controls.Add(this.label43);
            this.tabPage6.Controls.Add(this.label44);
            this.tabPage6.Controls.Add(this.label45);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(600, 553);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "REGISTRO ADMINISTRADORES";
            // 
            // txtTelefonoA
            // 
            this.txtTelefonoA.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefonoA.Location = new System.Drawing.Point(225, 269);
            this.txtTelefonoA.Name = "txtTelefonoA";
            this.txtTelefonoA.PasswordChar = '*';
            this.txtTelefonoA.Size = new System.Drawing.Size(196, 22);
            this.txtTelefonoA.TabIndex = 28;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(38, 269);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(63, 15);
            this.label39.TabIndex = 27;
            this.label39.Text = "Telefono";
            // 
            // txtUsuarioA
            // 
            this.txtUsuarioA.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioA.Location = new System.Drawing.Point(225, 46);
            this.txtUsuarioA.Name = "txtUsuarioA";
            this.txtUsuarioA.Size = new System.Drawing.Size(196, 22);
            this.txtUsuarioA.TabIndex = 26;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(38, 46);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(56, 15);
            this.label40.TabIndex = 25;
            this.label40.Text = "Usuario";
            // 
            // btnRegistrarA
            // 
            this.btnRegistrarA.Image = global::Proyecto_Ing.Properties.Resources.group_edit;
            this.btnRegistrarA.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegistrarA.Location = new System.Drawing.Point(225, 463);
            this.btnRegistrarA.Name = "btnRegistrarA";
            this.btnRegistrarA.Size = new System.Drawing.Size(120, 49);
            this.btnRegistrarA.TabIndex = 18;
            this.btnRegistrarA.Text = "REGISTRAR";
            this.btnRegistrarA.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRegistrarA.UseVisualStyleBackColor = true;
            // 
            // txtNombreAd
            // 
            this.txtNombreAd.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreAd.Location = new System.Drawing.Point(225, 101);
            this.txtNombreAd.Name = "txtNombreAd";
            this.txtNombreAd.Size = new System.Drawing.Size(196, 22);
            this.txtNombreAd.TabIndex = 24;
            // 
            // txtClaveA2
            // 
            this.txtClaveA2.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClaveA2.Location = new System.Drawing.Point(225, 386);
            this.txtClaveA2.Name = "txtClaveA2";
            this.txtClaveA2.PasswordChar = '*';
            this.txtClaveA2.Size = new System.Drawing.Size(196, 22);
            this.txtClaveA2.TabIndex = 23;
            // 
            // txtClaveA
            // 
            this.txtClaveA.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClaveA.Location = new System.Drawing.Point(225, 324);
            this.txtClaveA.Name = "txtClaveA";
            this.txtClaveA.PasswordChar = '*';
            this.txtClaveA.Size = new System.Drawing.Size(196, 22);
            this.txtClaveA.TabIndex = 22;
            // 
            // txtCedulaA
            // 
            this.txtCedulaA.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCedulaA.Location = new System.Drawing.Point(225, 212);
            this.txtCedulaA.Name = "txtCedulaA";
            this.txtCedulaA.Size = new System.Drawing.Size(196, 22);
            this.txtCedulaA.TabIndex = 21;
            // 
            // txtApellidoA
            // 
            this.txtApellidoA.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidoA.Location = new System.Drawing.Point(225, 159);
            this.txtApellidoA.Name = "txtApellidoA";
            this.txtApellidoA.Size = new System.Drawing.Size(196, 22);
            this.txtApellidoA.TabIndex = 20;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(38, 385);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(147, 15);
            this.label41.TabIndex = 19;
            this.label41.Text = "Confirmar Contraseña";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(38, 323);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(77, 15);
            this.label42.TabIndex = 17;
            this.label42.Text = "Contraseña";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(38, 211);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(49, 15);
            this.label43.TabIndex = 16;
            this.label43.Text = "Cedula";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(38, 161);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(63, 15);
            this.label44.TabIndex = 15;
            this.label44.Text = "Apellido";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(38, 103);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(49, 15);
            this.label45.TabIndex = 14;
            this.label45.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(335, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(285, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "PANEL ADMINISTRADORES";
            // 
            // btnProbar
            // 
            this.btnProbar.Image = global::Proyecto_Ing.Properties.Resources.database_lightning;
            this.btnProbar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProbar.Location = new System.Drawing.Point(160, 12);
            this.btnProbar.Name = "btnProbar";
            this.btnProbar.Size = new System.Drawing.Size(150, 57);
            this.btnProbar.TabIndex = 3;
            this.btnProbar.Text = "PROBAR CONEXION";
            this.btnProbar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnProbar.UseVisualStyleBackColor = true;
            // 
            // btnRegresar
            // 
            this.btnRegresar.Image = global::Proyecto_Ing.Properties.Resources.arrow_undo;
            this.btnRegresar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegresar.Location = new System.Drawing.Point(16, 12);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(113, 57);
            this.btnRegresar.TabIndex = 2;
            this.btnRegresar.Text = "REGRESAR";
            this.btnRegresar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.Location = new System.Drawing.Point(337, 12);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(63, 14);
            this.lblFecha.TabIndex = 4;
            this.lblFecha.Text = "--------";
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.Location = new System.Drawing.Point(553, 12);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(63, 14);
            this.lblHora.TabIndex = 5;
            this.lblHora.Text = "00:00:00";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txtMensaje
            // 
            this.txtMensaje.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMensaje.Location = new System.Drawing.Point(16, 670);
            this.txtMensaje.Multiline = true;
            this.txtMensaje.Name = "txtMensaje";
            this.txtMensaje.ReadOnly = true;
            this.txtMensaje.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMensaje.Size = new System.Drawing.Size(600, 70);
            this.txtMensaje.TabIndex = 14;
            // 
            // Panel_Adm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(632, 752);
            this.ControlBox = false;
            this.Controls.Add(this.txtMensaje);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.btnProbar);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.label1);
            this.Name = "Panel_Adm";
            this.Text = "Panel_Adm";
            this.Load += new System.EventHandler(this.Panel_Adm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbRegistra)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbBuscar)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtNombreE;
        private System.Windows.Forms.TextBox txtClaveE2;
        private System.Windows.Forms.TextBox txtClaveE;
        private System.Windows.Forms.TextBox txtCedulaE;
        private System.Windows.Forms.TextBox txtApellidoE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.Button btnProbar;
        private System.Windows.Forms.Button btnRegistrarE;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rbEuropa;
        private System.Windows.Forms.RadioButton rbAsia;
        private System.Windows.Forms.RadioButton rbAmerica;
        private System.Windows.Forms.TextBox txtCostoA;
        private System.Windows.Forms.TextBox txtNombreA;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.TextBox txtCodigoI;
        private System.Windows.Forms.Button btnRegistroM;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnBusca;
        private System.Windows.Forms.TextBox txtCodigoB;
        private System.Windows.Forms.Label lblUnidades;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnBusqueda;
        private System.Windows.Forms.Label lblCostosV;
        private System.Windows.Forms.Label lblCostos;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.TextBox txtCogioBA;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblOrigen;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnBuscaE;
        private System.Windows.Forms.Label lblAumento;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lblVentasE;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lblApellidoE;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblNombreE;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtBuscaE;
        private System.Windows.Forms.Button btnBuscaA;
        private System.Windows.Forms.TextBox txtBuscarA;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.LinkLabel lklblImagen;
        private System.Windows.Forms.PictureBox pcbRegistra;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox pcbBuscar;
        private System.Windows.Forms.TextBox txtTelefonoE;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtUsuarioE;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox txtTelefonoA;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtUsuarioA;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button btnRegistrarA;
        private System.Windows.Forms.TextBox txtNombreAd;
        private System.Windows.Forms.TextBox txtClaveA2;
        private System.Windows.Forms.TextBox txtClaveA;
        private System.Windows.Forms.TextBox txtCedulaA;
        private System.Windows.Forms.TextBox txtApellidoA;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtMensaje;
    }
}