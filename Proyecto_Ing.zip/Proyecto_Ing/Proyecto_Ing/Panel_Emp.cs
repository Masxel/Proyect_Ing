﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Ing
{
    public partial class Panel_Emp : Form
    {
        public Panel_Emp()
        {
            InitializeComponent();
        }
    }
}
