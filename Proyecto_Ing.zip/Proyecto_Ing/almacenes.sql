Create Database Almacenes
go

use Almacenes
go

-- drop database Almacenes

CREATE TABLE Administradores
(
Cedula bigint Primary Key,
Usuario nvarchar(30) Not null,
Nombre nvarchar(30) Not null,
Apellido nvarchar(30) Not null,
Telefono nvarchar(30) not null,
Clave nvarchar(30) Not null,
);
go


-- Volcado de datos para la tabla `administradores`
--

INSERT INTO Administradores VALUES
(1111, 'Yeison','Yeison Eduardo', 'Escobar','122222', '1234'),
(222222, 'Cristian','Cristian David','Alcaraz','147562', 'Gamer12');
go
-- -------------------------------------------------------


--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE Empleados (
  Cedula bigint Primary Key NOT NULL,
  Usuario nvarchar(30),
  Nombre nvarchar(30),
  Apellido nvarchar(30),
  Telefono nvarchar(30),
  Clave_Em nvarchar(30)
);
go

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO Empleados VALUES
(1236, 'Juan', 'Juan Pablo','Garzon','123545','1111'),
(1479, 'Mateo','Mateo', 'Vanegas', '99999','0000'),
(1478, 'Ximena', 'Ximena','Isaza', '15926','2222');
go
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logros`
--

CREATE TABLE Logros(
  Codigo bigint Primary Key identity(1,1),
  Ced_Emp bigint,
  Cod_Mer nvarchar(20),
  Ganancias bigint,
  Foreign Key (Ced_Emp)
  References Empleados(Cedula),
);
go

-- drop Table Logros
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mercancias`
--

CREATE TABLE Mercancias (
  Codigo nvarchar(20) Primary Key ,
  Marca nvarchar(20),
  Tipo nvarchar(20),
  Costo int,
  Precio_al_Publico int NOT NULL,
  Origen varchar(20),
  Imag Image);
go

--
-- Volcado de datos para la tabla `mercancias`
--

INSERT INTO Mercancias VALUES
('AJH78', 'SAMSUNG', 'ESTUFA', 1100000, 1200000, 1, 'America'),
('AL123', 'LG', 'Televisor', 600000, 630000, 1, 'Asia'),
('ALL1234', 'LG', 'Televisor', 900000, 1100000, 1, 'Asia'),
('ASL15', 'LG', 'Microondas', 300000, 385000, 1, 'Asia'),
('LMN14', 'SAMSUNG', 'Nevera', 850000, 1000000, 1, 'Europa'),
('MPQ124', 'KALLEY', 'Microondas', 200000, 270000, 1, 'America'),
('PAR258', 'Samsung', 'Televisor', 700000, 800000, 1, 'America');
go
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--



Create Table Ventas(
Codigo nvarchar(20) Primary Key
)

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO Ventas VALUES
('BCD369', 'HACEB', 'Nevera', 'Ramiro Alzate', 12345687, 1450000);
go

-- Usar la sintaxis FOREIGN KEY(campo_fk) REFERENCES nombre_tabla (nombre_campo)

Create Table Loguin(
Cedula_log bigint,
Usuario nvarchar(30),
Clave nvarchar(40),
Rol nvarchar(30),
Primary Key(Usuario)
);
go
-------------------------------------------------

--
-- Estructura de tabla para la tabla `controlasc`
--

CREATE TABLE Controlasc (
  Ced_Ing bigint Primary Key NOT NULL,
  Usuario nvarchar(30),
  Hora nvarchar(10),
  Fecha nvarchar(10)
  FOREIGN KEY (Usuario)
  REFERENCES Loguin(Usuario)
);
go

Create Table Usuario(
Cedula bigint Primary Key,
Nombre nvarchar(30),
Apellido nvarchar(30),
Telefono nvarchar(30),
);

CREATE TABLE Factura(
  Codigo bigint,
  Ced_Emp bigint,
  Ced_Comp bigint,
  Cod_Mer nvarchar(20),
  Cantidad smallint,
  Total bigint,
  Foreign Key (Ced_Emp)
  References Empleados(Cedula),
  Foreign Key (Cod_Mer)
  References Mercancias(Codigo),
  Foreign Key (Ced_Comp)
  References Usuario(Cedula),
  Primary Key (Ced_Emp,Cod_Mer,Codigo,Ced_Comp)
);
go
--

-- --------------------------------------------------------


Create procedure Agregar_Adm @Ced Bigint, @Usuario nvarchar(30), @Nombre nvarchar(30), @Apellido nvarchar(30),@Tel nvarchar(30), @Clave nvarchar(30) As

if Exists(Select * From Administradores A Where A.Cedula = @Ced)
 Print 'El Administrador Ya Existe.... Intente De Nuevo'
 Else
 Insert Into Administradores Values
(@Ced, @Usuario, @Nombre, @Apellido, @Tel, @Clave);
go
 --Agregar_Adm 114,'Juan', 'Juan Esteban','Rico','1564','12345'

Create Trigger Trigger1 On Administradores After Insert As

  Declare @CD Bigint
  Declare @Us nvarchar(30)
  Declare @Cla nvarchar(30)

  Select @CD=Cedula, @Us=Usuario, @Cla=Clave
  From Inserted
  Insert Into Loguin Values
  (@CD, @Us, @Cla, 'Administrador');
go

Create procedure Agregar_Emp @Ced Bigint, @Usuario nvarchar(30), @Nombre nvarchar(30), @Apellido nvarchar(30), @Tel nvarchar(30), @Clave nvarchar(30) As

if Exists(Select * From Administradores A Where A.Cedula = @Ced)
 Print 'El Empleado Ya Existe.... Intente De Nuevo'
 Else
 Insert Into Empleados Values
(@Ced, @Usuario, @Nombre, @Apellido,@Tel, @Clave);
go

Create Trigger Trigger2 On Empleados After Insert As

  Declare @CD Bigint
  Declare @Us nvarchar(30)
  Declare @Cla nvarchar(30)
  Select @CD=Cedula, @Us=Usuario, @Cla=Clave_Em
  From Inserted
  Insert Into Loguin Values
  (@CD, @Us, @Cla, 'Empleado')
go

Create procedure Acceso @Ced Bigint, @Usuario nvarchar(30), @Hora nvarchar(30), @fecha nvarchar(30) As
if Exists(Select * From Controlasc C Where C.Usuario = @Usuario)
 Update Controlasc Set Hora = @Hora, Fecha = @Fecha  WHERE Usuario = @Usuario; 
 Else
 Insert Into Controlasc Values
(@Ced, @Usuario, @Hora, @fecha);
go

CREATE PROCEDURE Consultausu
	@usu nvarchar(30)  
AS
BEGIN
	SELECT * from Loguin where Usuario = @usu;
END
GO

-- Drop procedure Acceso


 -- Execute Agregar_Emp 117,'Juanes','Juan Esteban','Rico','1234', '12333'

-- Drop Trigger Trigger1
--drop Trigger Trigger2